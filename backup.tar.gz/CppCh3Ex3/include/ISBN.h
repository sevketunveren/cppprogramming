#include <ctime>
#include <iostream>
#include <string>
#include <stdexcept>
#define ISBNSIZE 14
using namespace std;

class ISBN
{
public:
    ISBN(const string pisbn);
private:
    ISBN();
    const string isbn;
};
