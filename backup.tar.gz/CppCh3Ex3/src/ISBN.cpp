#include <ISBN.h>

ISBN::ISBN(const string pisbn):isbn(pisbn)
{
    if(pisbn.length()>14)
    {
        
    }
}