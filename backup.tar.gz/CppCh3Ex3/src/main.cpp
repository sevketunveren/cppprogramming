#include <iostream>
#include <ISBN.h>

int main()
{
    ISBN i("seasdasdasdasdsadvket");
    return 0;
}